package edu.vanderbilt.mooc.moocprovider;

import android.net.Uri;

public final class StoriesContract {

	public static final String AUTHORITY = "edu.vanderbilt.mooc.moocprovider";
	public static final Uri BASE_URI = Uri
			.parse("content://" + AUTHORITY + "/");

	public static final String STORIES_TABLE_NAME = "tags_table";

	// The URI for this table.
	public static final Uri CONTENT_URI = Uri.withAppendedPath(BASE_URI,
			STORIES_TABLE_NAME);

	public static final String _ID = "_ID";
	public static final String LOGIN_ID = "LOGIN_ID";
	public static final String STORY_ID = "STORY_ID";
	public static final String TITLE = "TITLE";
	public static final String BODY = "BODY";
	public static final String AUDIO_LINK = "AUDIO_LINK";
	public static final String VIDEO_LINK = "VIDEO_LINK";
	public static final String IMAGE_NAME = "IMAGE_NAME";
	public static final String IMAGE_LINK = "IMAGE_LINK";
	public static final String TAGS = "TAGS";
	public static final String CREATION_TIME = "CREATION_TIME";
	public static final String STORY_TIME = "STORY_TIME";
	public static final String LATITUDE = "LATITUDE";
	public static final String LONGITUDE = "LONGITUDE";

}
