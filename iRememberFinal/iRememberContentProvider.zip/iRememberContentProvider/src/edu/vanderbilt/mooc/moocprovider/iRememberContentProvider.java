package edu.vanderbilt.mooc.moocprovider;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;

public class iRememberContentProvider extends ContentProvider {

	private SQLiteDatabase database;
	private static final int DATABASE_VERSION = 1;
	private static final String DATABASE_NAME = "Stories";
	

	private static final String CREATE_STORIES_TABLE = " CREATE TABLE "
			+ StoriesContract.STORIES_TABLE_NAME + " (" + StoriesContract._ID
			+ " INTEGER PRIMARY KEY AUTOINCREMENT, "
			+ StoriesContract.LOGIN_ID + " TEXT NOT NULL, "
			+ StoriesContract.STORY_ID + " TEXT NOT NULL, "
			+ StoriesContract.BODY + " TEXT NOT NULL, "
			+ StoriesContract.AUDIO_LINK + " TEXT NOT NULL, "
			+ StoriesContract.VIDEO_LINK + " TEXT NOT NULL, "
			+ StoriesContract.IMAGE_NAME + " TEXT NOT NULL, "
			+ StoriesContract.IMAGE_LINK + " TEXT NOT NULL, "
			+ StoriesContract.TAGS + " TEXT NOT NULL, "
			+ StoriesContract.CREATION_TIME + " TEXT NOT NULL, "
			+ StoriesContract.STORY_TIME + " TEXT NOT NULL, "
			+ StoriesContract.LATITUDE + " REAL NOT NULL, "
			+ StoriesContract.LONGITUDE + " REAL NOT NULL);";

	private static class DatabaseHelper extends SQLiteOpenHelper {

		public DatabaseHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			db.execSQL(CREATE_STORIES_TABLE);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			db.execSQL("DROP TABLE IF EXISTS " + StoriesContract.STORIES_TABLE_NAME);
			onCreate(db);
		}

	}

	@Override
	public int delete(Uri arg0, String arg1, String[] arg2) {
		int rowsDeleted = database.delete(StoriesContract.STORIES_TABLE_NAME, null, null);
		getContext().getContentResolver().notifyChange(StoriesContract.CONTENT_URI, null);
		return rowsDeleted;

	}

	@Override
	public String getType(Uri arg0) {
		// unimplemented
		return null;
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		long rowID = database.insert(StoriesContract.STORIES_TABLE_NAME, "", values);

		if (rowID > 0) {
			Uri _uri = ContentUris.withAppendedId(
					StoriesContract.CONTENT_URI, rowID);
			getContext().getContentResolver().notifyChange(_uri, null);
			return _uri;
		}
		throw new SQLException("Failed to add record into" + uri);
	}

	@Override
	public boolean onCreate() {
		DatabaseHelper dbHelper = new DatabaseHelper(getContext());
		database = dbHelper.getWritableDatabase();
		return (database != null);
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {
		
		SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

		qb.setTables(StoriesContract.STORIES_TABLE_NAME);

		Cursor c = qb.query(database, null, null, null, null, null, null);

		c.setNotificationUri(getContext().getContentResolver(), uri);

		return c;
	
	}

	@Override
	public int update(Uri arg0, ContentValues arg1, String arg2, String[] arg3) {
		// unimplemented
		return 0;
	}

}
